<?php

require_once("../model/productos_model.php");

?>